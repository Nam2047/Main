﻿using System;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            int age = 8;
            double height = 178.7, weight = 60.7;
            bool IsWithParent = true;
            string FirstName = "Jack";
            string LastName = "Jone";
            if( age >= 10 || IsWithParent)
            {
                double BMI = weight / Math.Pow((height / 100), 2);
                Console.WriteLine ("Your BMI is " + BMI);
            }
            else
            {
                Console.WriteLine ("You are not old enough, please come back with your parents, " + FirstName + " " + LastName + ".");
            }
        }
    }
}