﻿using System;

namespace Object
{
    class Program
    {
        static void Main(string[] args)
        {
            Ball soccer = new Ball(17, "Black", "ABC company");
            soccer.InformationOfTheBall();
            Console.WriteLine("\nPress any key to exit");
            Console.ReadLine();
            Console.WriteLine("Thank you and have a nice day!");
        }
    }
    public class Ball
    {
        public int Size { get; set; }
        public string Color { get; set; }
        public string Madeby { get; set; }
        public Ball(int size, string color, string madeby)
        {
            Size = size;
            Color = color;
            Madeby = madeby;
        }
        public void InformationOfTheBall()
        {
            Console.WriteLine("Size: {0}cm\nColor: {1}\nMade by: {2}", Size, Color, Madeby);
        }
    }
}